lasttime = 0;

hey_ganyu = function()
{
	lasttime = sys.epochMillis;
	sys.out.println("Yes?");
}

last_hey = function()
{
	if (sys.epochMillis - lasttime > 3000)
		return false;
	sys.out.println("Ok.");
	return true;
}

sys.out.println("Loaded ganyu stuff");
